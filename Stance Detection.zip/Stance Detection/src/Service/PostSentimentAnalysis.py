import nltk
import pandas as pd
import numpy as np
from .TextExtraction import  DebateAnalyzer

