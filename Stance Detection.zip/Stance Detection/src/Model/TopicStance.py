import pandas
class TopicStance:
	def __init__(self,topicId,topicStanceId,stance):
		self.topicId=topicId
		self.topicStanceId= topicStanceId
		self.stance= stance