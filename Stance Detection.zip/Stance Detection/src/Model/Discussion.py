class Discussion:
    def __init__(self, discussionId, title, initiatingAuthorId):
        self.discussionId = discussionId
        self.title = title
        self.initiatingAuthorId = initiatingAuthorId
