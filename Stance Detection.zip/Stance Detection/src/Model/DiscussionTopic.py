import pandas
class DiscussionTopic:
	def __init__(self,discussionId,topicId):
		self.discussionId = discussionId
		self.topicId = topicId