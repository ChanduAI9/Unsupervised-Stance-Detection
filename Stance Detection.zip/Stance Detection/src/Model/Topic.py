class Topic:
	def __init__(self,topicId,topic):
		self.topicId=topicId
		self.topic= topic
		