import pandas


class DiscussionStance:
    def __init__(self, discussionId, discussionStanceId, discussionStance):
        self.discussionId = discussionId
        self.discussionStance = discussionStance
        self.discussionStanceId = discussionStanceId
