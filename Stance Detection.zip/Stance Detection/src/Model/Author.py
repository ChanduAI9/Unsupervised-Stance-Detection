class Author:
	def __init__(self,authorId):
		self.authorId=authorId
