import pandas
class Quote:
	def __init__(self,discussionId,postId,sourcePostId):
		self.discussionId = discussionId
		self.postId=postId
		self.sourcePostId=sourcePostId